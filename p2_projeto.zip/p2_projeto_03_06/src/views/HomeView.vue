<template>
  <div class="text-center">
    <h1 class="text-4xl font-bold mb-4">Bem-vindo à nossa loja</h1>
    <p class="text-lg">Veja nossos produtos incríveis na aba de produtos!</p>
  </div>
</template>
