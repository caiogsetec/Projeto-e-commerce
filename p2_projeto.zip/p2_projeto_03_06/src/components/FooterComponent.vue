<template>
  <footer class="bg-orange text-white p-4 text-center">
    <p>&copy; 2025 - E-commerce Turma C - ADS</p>
  </footer>
</template>
